<?php $__env->startSection('title','Membership'); ?>
<?php $__env->startSection('content'); ?>                           
<!--Page header-->
<div class="page-header d-lg-flex d-block">
    <div class="page-leftheader">
        <h4 class="page-title">Membership</h4>
    </div>
</div>
<!--End Page header-->

<div class="row">
    <div class="col-xl-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header  border-0">
                <h4 class="card-title">Membership</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap border-bottom" id="basic-datatable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0 w-5">No</th>
                                <th class="border-bottom-0">User</th>
                                <th class="border-bottom-0">Packages Name</th>
                                <th class="border-bottom-0">Packages Price</th>
                                <th class="border-bottom-0">Payment ID</th>
                                <th class="border-bottom-0">Status</th>
                                <th class="border-bottom-0">Date/Time</th>
                                <!-- <th class="border-bottom-0">Actions</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Membership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <span class="avatar avatar-md brround mr-3" style="background-image: url('<?php echo e($value->profile); ?>')"></span>
                                            <div class="mr-3 mt-0 mt-sm-1 d-block">
                                                <h6 class="mb-1 fs-14"><?php echo e($value->firstname); ?> <?php echo e($value->lastname); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($value->package_name); ?></td>
                                    <td><?php echo e($value->price); ?></td>
                                    <td><?php echo e($value->payment_id); ?></td>
                                    <td>
                                        <?php if($value->status==1): ?>
                                            <span class="badge badge-success">Success</span>
                                        <?php elseif($value->status==0): ?>
                                            <span class="badge badge-warning">Awaiting</span>
                                        <?php elseif($value->status==2): ?>
                                            <span class="badge badge-danger">Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($value->created_at); ?></td>
                                    <!-- <td class="text-left d-flex">
                                        <a class="action-btns1" onclick="editabuse_report('<?php echo e($value->id); ?>')">
                                            <i class="feather feather-edit text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="view"></i>
                                        </a>
                                    </td> -->
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/dating_app/resources/views/admin/membership/list.blade.php ENDPATH**/ ?>