<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('content'); ?>                           
<!--Page header-->
<div class="page-header d-lg-flex d-block">
    <div class="page-leftheader">
        <h4 class="page-title">Users</h4>
    </div>
</div>
<!--End Page header-->

<div class="row">
    <div class="col-xl-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header  border-0">
                <h4 class="card-title">Users List</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap border-bottom" id="basic-datatable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0 w-5">No</th>
                                <th class="border-bottom-0">Name</th>
                                <th class="border-bottom-0 w-10">Email</th>
                                <th class="border-bottom-0">Gender</th>
                                <th class="border-bottom-0">DOB</th>
                                <th class="border-bottom-0">Interests</th>
                                <th class="border-bottom-0">Join Date</th>
                                <th class="border-bottom-0">Status</th>
                                <th class="border-bottom-0">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <span class="avatar avatar-md brround mr-3" style="background-image: url('<?php echo e($value->profile); ?>')"></span>
                                            <div class="mr-3 mt-0 mt-sm-1 d-block">
                                                <h6 class="mb-1 fs-14"><?php echo e($value->firstname); ?> <?php echo e($value->lastname); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($value->email); ?></td>
                                    <td><?php echo e($value->gender); ?></td>
                                    <td><?php echo e($value->dob); ?></td>
                                    <td>
                                        <?php $interests = explode(',', $value->interests); ?>
                                        <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $interest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="btn btn-sm btn-white mt-1" href="#"><?php echo e(ucfirst($interest)); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($value->created_at); ?></td>
                                    <td>
                                        <?php if($value->status==1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php elseif($value->status==0): ?>
                                            <span class="badge badge-danger">Deactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-left d-flex">
                                        <a href="<?php echo e(URL::to('viewuser/'.$value->id)); ?>" class="action-btns1">
                                            <i class="feather feather-eye  text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="view"></i>
                                        </a>
                                        <a href="<?php echo e(URL::to('deleteuser/'.$value->id)); ?>" class="action-btns1" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
                                            <i class="feather feather-trash-2 text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/dating_app/resources/views/admin/users/list.blade.php ENDPATH**/ ?>