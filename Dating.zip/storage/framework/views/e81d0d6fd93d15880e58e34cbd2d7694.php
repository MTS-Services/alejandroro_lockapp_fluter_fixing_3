<?php $__env->startSection('title','Abuse Report'); ?>
<?php $__env->startSection('content'); ?>                           
<!--Page header-->
<div class="page-header d-lg-flex d-block">
    <div class="page-leftheader">
        <h4 class="page-title">Abuse Report</h4>
    </div>
</div>
<!--End Page header-->

<div class="row">
    <div class="col-xl-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header  border-0">
                <h4 class="card-title">Abuse Report</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap border-bottom" id="basic-datatable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0 w-5">No</th>
                                <th class="border-bottom-0">Reported By User</th>
                                <th class="border-bottom-0">Reported to User</th>
                                <th class="border-bottom-0">Reason</th>
                                <th class="border-bottom-0">Remarks</th>
                                <th class="border-bottom-0">Date/Time</th>
                                <th class="border-bottom-0">Status</th>
                                <th class="border-bottom-0">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $AbuseReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <span class="avatar avatar-md brround mr-3" style="background-image: url('<?php echo e($value->profile); ?>')"></span>
                                            <div class="mr-3 mt-0 mt-sm-1 d-block">
                                                <h6 class="mb-1 fs-14"><?php echo e($value->firstname); ?> <?php echo e($value->lastname); ?></h6>
                                                <div class="d-flex">
                                                    <a href="<?php echo e(URL::to('viewuser/'.$value->user_id)); ?>" class="action-btns1" data-toggle="tooltip" data-placement="top" title="" data-original-title="View User Details"><i class="feather feather-send text-info"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <span class="avatar avatar-md brround mr-3" style="background-image: url('<?php echo e($value->re_profile); ?>')"></span>
                                            <div class="mr-3 mt-0 mt-sm-1 d-block">
                                                <h6 class="mb-1 fs-14"><?php echo e($value->re_firstname); ?> <?php echo e($value->re_lastname); ?></h6>
                                                <div class="d-flex">
                                                    <a href="<?php echo e(URL::to('viewuser/'.$value->reported_userid)); ?>" class="action-btns1" data-toggle="tooltip" data-placement="top" title="" data-original-title="View User Details"><i class="feather feather-send text-info"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($value->reason); ?></td>
                                    <td><?php echo e($value->remarks); ?></td>
                                    <td><?php echo e($value->created_at); ?></td>
                                    <td>
                                        <?php if($value->status==1): ?>
                                            <span class="badge badge-success">Accepted</span>
                                        <?php elseif($value->status==0): ?>
                                            <span class="badge badge-warning">Awaiting</span>
                                        <?php elseif($value->status==2): ?>
                                            <span class="badge badge-danger">Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-left d-flex">
                                        <a class="action-btns1" onclick="editabuse_report('<?php echo e($value->id); ?>')">
                                            <i class="feather feather-edit text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="view"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade"  id="abuse_report_modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">My Leave Application</h5>
                <button  class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="abuse_report_body">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
    function editabuse_report(id) {
        $.ajax({
            type: 'get',
            dataType:'html',
            url: "<?php echo e(URL::to('editabuse_report')); ?>/"+id,
            success: function (result) {
                $('#abuse_report_modal').modal('show');
                $('#abuse_report_modal .modal-title').html('Report Moderation');
                $('#abuse_report_body').html(result);
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/dating_app/resources/views/admin/abuse/list.blade.php ENDPATH**/ ?>