<?php if(isset($package_data)): ?>
    <form method="POST" action="<?php echo e(URL::to('editpackages')); ?>">
        <input type="hidden" name="id" value="<?php echo e($package_data->id); ?>">
<?php else: ?>
    <form method="POST" action="<?php echo e(URL::to('addpackages')); ?>">
<?php endif; ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <div class="form-group">
                <label class="form-label">Package Name</label>
                <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="package_name" value="<?php if(isset($package_data)): ?><?php echo e($package_data->package_name); ?><?php endif; ?>" placeholder="Package Name" required>
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
            <div class="form-group">
                <label class="form-label">Package Price</label>
                <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="price" value="<?php if(isset($package_data)): ?><?php echo e($package_data->price); ?><?php endif; ?>" placeholder="Package Price" required>
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-sm-12 col-md-12">
            <div class="form-group">
                <label class="form-label">Credits</label>
                <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="credits" value="<?php if(isset($package_data)): ?><?php echo e($package_data->credits); ?><?php endif; ?>" placeholder="Package Credits" required>
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <?php if(isset($package_data)): ?>
            <div class="col-sm-12 col-md-12">
                <div class="custom-controls-stacked d-md-flex">
                    <label class="form-label mt-1 mr-5">Status :</label>
                    <label class="custom-control custom-radio success mr-4">
                        <input type="radio" class="custom-control-input" name="status" value="1" <?php if($package_data->status==1): ?> checked="" <?php endif; ?>>
                        <span class="custom-control-label">Enable</span>
                    </label>
                    <label class="custom-control custom-radio success mr-4">
                        <input type="radio" class="custom-control-input" name="status" value="0" <?php if($package_data->status==0): ?> checked="" <?php endif; ?>>
                        <span class="custom-control-label">Disable</span>
                    </label>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-sm-12 col-md-12 mt-4">
            <div class="form-group">
                <button type="submit" class="btn btn-lg btn-primary">Submit</button>
            </div>
        </div>
    </div>
</form><?php /**PATH /var/www/html/dating_app/resources/views/admin/packages/add.blade.php ENDPATH**/ ?>