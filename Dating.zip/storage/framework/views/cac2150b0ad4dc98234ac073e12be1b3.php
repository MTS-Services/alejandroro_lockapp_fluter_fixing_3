<h1>Forgot Password</h1>

You can reset password from below link:
<a href="<?php echo e(URL::to('reset-password/'.$token)); ?>">Reset Password</a><?php /**PATH /var/www/html/dating_app/resources/views/forgetPassword.blade.php ENDPATH**/ ?>