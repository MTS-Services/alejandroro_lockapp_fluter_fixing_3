<?php $__env->startSection('title','Credit Packages'); ?>
<?php $__env->startSection('content'); ?>                           
<!--Page header-->
<div class="page-header d-lg-flex d-block">
    <div class="page-leftheader">
        <h4 class="page-title">Credit Packages</h4>
    </div>
    <div class="page-rightheader ml-md-auto">
        <div class="btn-list">
            <button class="btn btn-success" onclick="addpackages()" data-placement="top" data-toggle="tooltip" title="" data-original-title="Add Package"> Add Package</button>
        </div>
    </div>
</div>
<!--End Page header-->

<div class="row">
    <div class="col-xl-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-header  border-0">
                <h4 class="card-title">Credit Packages</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered text-nowrap border-bottom" id="basic-datatable">
                        <thead>
                            <tr>
                                <th class="border-bottom-0 w-5">No</th>
                                <th class="border-bottom-0">Packages Name</th>
                                <th class="border-bottom-0">Packages Price</th>
                                <th class="border-bottom-0">Credits</th>
                                <th class="border-bottom-0">Status</th>
                                <th class="border-bottom-0">Date/Time</th>
                                <th class="border-bottom-0">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key+1); ?></td>
                                    <td><?php echo e($value->package_name); ?></td>
                                    <td><?php echo e($value->price); ?></td>
                                    <td><?php echo e($value->credits); ?></td>
                                    <td>
                                        <?php if($value->status==1): ?>
                                            <span class="badge badge-success">Enable</span>
                                        <?php elseif($value->status==0): ?>
                                            <span class="badge badge-danger">Disable</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($value->created_at); ?></td>
                                    <td class="text-left d-flex">
                                        <a class="action-btns1" onclick="editpackages('<?php echo e($value->id); ?>')">
                                            <i class="feather feather-edit text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="view"></i>
                                        </a>
                                        <a href="<?php echo e(URL::to('deletepackages/'.$value->id)); ?>" class="action-btns1" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
                                            <i class="feather feather-trash-2 text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade"  id="packages_modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button  class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body" id="packages_body">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
    function addpackages() {
        $.ajax({
            type: 'get',
            dataType:'html',
            url: "<?php echo e(URL::to('addpackages')); ?>",
            success: function (result) {
                $('#packages_modal').modal('show');
                $('#packages_modal .modal-title').html('Add Package');
                $('#packages_body').html(result);
            }
        });
    }
    function editpackages(id) {
        $.ajax({
            type: 'get',
            dataType:'html',
            url: "<?php echo e(URL::to('editpackages')); ?>/"+id,
            success: function (result) {
                $('#packages_modal').modal('show');
                $('#packages_modal .modal-title').html('Edit Package');
                $('#packages_body').html(result);
            }
        });   
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/dating_app/resources/views/admin/packages/list.blade.php ENDPATH**/ ?>