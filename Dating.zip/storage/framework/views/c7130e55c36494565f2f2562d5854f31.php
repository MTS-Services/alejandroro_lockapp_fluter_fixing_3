<?php $__env->startSection('title','Update Password'); ?>
<?php $__env->startSection('content'); ?>                           
<!--Page header-->
<div class="page-header d-lg-flex d-block">
    <div class="page-leftheader">
        <h4 class="page-title">Update Password</h4>
    </div>
</div>
<!--End Page header-->

<!-- Row -->
<div class="row">
    <div class="col-xl-4 col-lg-5">
        <div class="card">
            <div class="card-header border-bottom-0">
                <div class="card-title">Update Password</div>
            </div>
            <form method="POST" action="<?php echo e(URL::to('updatepassword')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-control<?php echo e($errors->has('current_password') ? ' is-invalid' : ''); ?>" name="current_password" placeholder="Current Password" required>
                        <?php if($errors->has('current_password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('current_password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input type="password" class="form-control<?php echo e($errors->has('new_password') ? ' is-invalid' : ''); ?>" name="new_password" placeholder="New Password" required>
                        <?php if($errors->has('new_password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('new_password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" class="form-control<?php echo e($errors->has('confirm_password') ? ' is-invalid' : ''); ?>" name="confirm_password" placeholder="Confirm Password" required>
                        <?php if($errors->has('confirm_password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('confirm_password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary">Updated</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- End Row-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customjs'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/dating_app/resources/views/admin/profile/password.blade.php ENDPATH**/ ?>